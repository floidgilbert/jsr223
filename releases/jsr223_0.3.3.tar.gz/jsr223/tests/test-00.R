library("jsr223")

# As of Java 11, Nashorn JavaScript has been deprecated. No other script engines
# are guaranteed to be available by default. Hence, all of the automated tests
# have been removed from the package as of jsr223 version 0.3.3.

